Adjuntamos una copia del código fuente, tanto de cliente
como de servidor por si hubiera cualquier error con alguno 
de los archivos.

Muchas gracias,

  un saludo.